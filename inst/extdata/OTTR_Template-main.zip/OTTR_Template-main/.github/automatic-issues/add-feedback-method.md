
To help users report issues or areas of improvement for your course, you should provide a clear method of feedback for your users to route their concerns through.

- [ ] [Read this chapter from an OTTR-made course about how to obtain user feedback](https://jhudatascience.org/Documentation_and_Usability/obtaining-user-feedback.html).

It's also a good idea to collect passive feedback via Google Analytics.

- [ ] [Read our guide to Google Analytics here](https://www.ottrproject.org/more_features.html#google-analytics).
