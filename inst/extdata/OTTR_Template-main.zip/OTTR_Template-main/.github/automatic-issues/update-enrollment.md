
The original template: https://github.com/jhudsl/OTTR_Template is always a work in progress.
We are working on adding more features and smoothing out bugs as we go.

If you want to receive updates from the original template to your course template, you will need to enroll this repository to the template updates by adding it to the `sync.yml` file.

- [ ] [Follow these instructions](https://www.ottrproject.org/getting_started.html#9_Enroll_your_repository_for_OTTR_updates) to enroll your course repository to receive these updates.
