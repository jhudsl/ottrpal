# About this Course
 
{type: iframe, title:About this Course, width:800, height:600, poster:resources/chapt_screen_images/index.png}
![](https://jhudatascience.org/OTTR_Template/no_toc/index.html)
 

 
