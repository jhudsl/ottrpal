# About the Authors
 
{type: iframe, title:About the Authors, width:800, height:600, poster:resources/chapt_screen_images/about-the-authors.png}
![](https://jhudatascience.org/OTTR_Template/about-the-authors.html)
 

 
