---
name: Add new repository to sync
about: Enroll your repository for OTTR updates
title: OTTR Updates Enrollment
labels: ''
assignees: cansavvy
---

Added __ repository to sync.yml in order to enroll in OTTR updates.
