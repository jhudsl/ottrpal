# Conclusion
 
{type: iframe, title:Conclusion, width:800, height:600, poster:resources/chapt_screen_images/conclusion.png}
![](http://hutchdatascience.org/OTTR_Quarto/conclusion.html)
 

 
