- [ ] Fill in the `About.Rmd` page to give credit to authors and contributors.

For more information about the `About.Rmd` page, see [the ottr instructions](https://www.ottrproject.org/more_features.html#Giving_credits_to_contributors).
