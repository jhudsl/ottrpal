# rgoogleclassroom 0.9.1

* Some issues with ottrpal_translate()'s handling of quizzes were fixed. 
