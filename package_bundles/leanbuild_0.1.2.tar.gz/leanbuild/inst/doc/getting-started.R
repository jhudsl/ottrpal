## -----------------------------------------------------------------------------
if (!("remotes" %in% installed.packages())) {
  install.packages("remotes")
}
if (!("leanbuild" %in% installed.packages())) {
  remotes::install_github("jhudsl/leanbuild")
}

## -----------------------------------------------------------------------------
# Run this to get the files we need
example_files <- leanbuild::example_repo_setup()

## -----------------------------------------------------------------------------
leanbuild::bookdown_to_leanpub(make_book_txt = TRUE, quiz_dir = NULL)

## -----------------------------------------------------------------------------
leanbuild::bookdown_to_book_txt()

## -----------------------------------------------------------------------------
readLines(file.path("manuscript", "Book.txt"))

## -----------------------------------------------------------------------------
quiz_dir <- "quizzes"
if(!dir.exists(quiz_dir)) {
  dir.create(quiz_dir)
}

## -----------------------------------------------------------------------------
# Set up an good example quiz
good_quiz_path <- leanbuild::good_quiz_path()

dest_quiz_path <- file.path("quizzes", basename(good_quiz_path))
              
if (!file.exists(dest_quiz_path)){         
  file.copy(from = good_quiz_path, 
            to = dest_quiz_path)
}

## -----------------------------------------------------------------------------
quiz_checklist <- leanbuild::check_quizzes(quiz_dir = "quizzes")

## -----------------------------------------------------------------------------
quiz_lines <- readLines(dest_quiz_path)
head(quiz_lines)

## -----------------------------------------------------------------------------
# Set up an good example quiz
bad_quiz_path <- leanbuild::bad_quiz_path()

dest_quiz_path <- file.path("quizzes", basename(bad_quiz_path))

if (!file.exists(dest_quiz_path)){                
  file.copy(from = bad_quiz_path, 
            to = dest_quiz_path)
}

## -----------------------------------------------------------------------------
quiz_checklist <- leanbuild::check_quizzes(quiz_dir = "quizzes")

## -----------------------------------------------------------------------------
error_df <- readr::read_tsv("question_error_report.tsv")

error_df

## -----------------------------------------------------------------------------
# Set up a character string
survey_link <- "Please provide any feedback you have in [this survey](www.some_link.org)"

# Supply the footer text in the main function
leanbuild::bookdown_to_leanpub(make_book_txt = TRUE, 
                               footer_text = survey_link)

## ---- echo = FALSE, results = FALSE-------------------------------------------
leanbuild::example_repo_cleanup(files_to_remove = basename(example_files), verbose = FALSE)

## -----------------------------------------------------------------------------
sessionInfo()

