
{quiz, id: quiz_name_here, attempts: 10}

## Template quiz

Put any other instructions your quiz takers need to know here like: Choose the best answer.

{choose-answers: 4}
? It would be a shame if we put a colon here: because that will break this.

C) One correct answer here marked with a "C"
C) A second correct answer here
m) Mandatory incorrect answers have an "m"
m) A second mandatory incorrect answer
o) An optional incorrect answer here marked with an "o"
o) A second optional incorrect answer here

? What a shame if we put an exclamation point in one of these questions

a) A first wrong answer!
B) The correct answer which is capitalized!
c) Some wrong answer
d) Some other wrong answer

{choose-answers: 6}
? Shame shame if we say more choose-answers than there are answer options

C) One correct answer here marked with a "C"
m) Mandatory incorrect answers have an "m"
m) A second mandatory incorrect answer
o) An optional incorrect answer here marked with an "o"

{choose-answers: 4}
? What if we don't put a correct answer

c) We didn't specify a correct answer
m) What a shame
o) So sad.

? What if only give correct answers?

A) Oh no
B) How horrible
C) Is everything correct?

{/quiz}
