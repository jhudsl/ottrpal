library(testthat)
library(leanbuild)

test_check("leanbuild")
